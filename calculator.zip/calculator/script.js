const operand = prompt("Enter  +,-,*,/");
const num1 = Number(prompt("Enter a"));
const num2 = Number(prompt("Enter b"));

function Calculator(a, b) {

    switch (operand) {
        case "+":
            return num1 + num2;

        case "-":
            return num1 - num2;

        case "*":
            return num1 * num2;

        case "/":
            return num1 / num2;
    }
}

alert(num1 + operand + num2 + '=' + Calculator());