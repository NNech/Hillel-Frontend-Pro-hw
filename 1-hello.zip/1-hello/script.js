const userName = prompt("What is your name?");
alert("Hello, " + userName + " ! How are you?");

const userAge = prompt("How old are you?");
if (userAge > 18) {
    alert("access allowed.");
}
else {
    alert("access forbidden.");
}


